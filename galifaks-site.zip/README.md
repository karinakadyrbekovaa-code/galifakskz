# Galifaks Furniture

Одностраничный сайт компании Galifaks (офисная мебель, Алматы).

Структура: `index.html` — страница, `style.css` — стили, `images/` — фотографии.
